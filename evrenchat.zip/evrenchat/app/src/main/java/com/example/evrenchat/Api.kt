package com.example.evrenchat

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(val status: Int, val code: String, message: String) : Exception(message)

sealed interface Ev {
    data class Text(val s: String) : Ev
    data class Think(val s: String) : Ev
    data class Usage(val prompt: Int, val completion: Int) : Ev
}

class ChatParams(
    val base: String,
    val key: String,
    val model: String,
    val temperature: Float,
    val maxTokens: Int,
    val stream: Boolean,
)

/** OpenAI uyumlu (Evren LLM geçidi dahil) sohbet istemcisi. */
object Api {
    // Uydu gibi yavaş/yüksek gecikmeli bağlantılar için uzun zaman aşımları
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val JSON_TYPE = "application/json".toMediaType()
    private val parser = Json { ignoreUnknownKeys = true }

    private fun url(base: String, path: String) = base.trim().trimEnd('/') + path

    private fun builder(base: String, key: String, path: String) =
        Request.Builder().url(url(base, path))
            .header("Authorization", "Bearer ${key.trim()}")
            .header("X-API-Key", key.trim())
            .header("User-Agent", "EvrenSohbet/1.0")

    private fun JsonElement?.str(): String? =
        (this as? JsonPrimitive)?.takeIf { it.isString }?.content

    private fun errMessage(el: JsonElement?): String = when (el) {
        is JsonObject -> el["message"].str() ?: el["detail"].str() ?: el.toString().take(300)
        is JsonPrimitive -> el.content
        else -> "Bilinmeyen hata"
    }

    private fun errCode(el: JsonElement?): String = when (el) {
        is JsonObject -> el["code"].str() ?: el["type"].str() ?: ""
        else -> ""
    }

    private fun parseError(status: Int, body: String): ApiException {
        val o = runCatching { parser.parseToJsonElement(body).jsonObject }.getOrNull()
        if (o == null) return ApiException(status, "", body.trim().take(300).ifBlank { "HTTP $status" })
        val e = o["error"]
        val code = (errCode(e).ifBlank { o["code"].str().orEmpty() }).ifBlank { o["error"].str().orEmpty() }
        val msg = when {
            e != null -> errMessage(e)
            o["detail"] != null -> errMessage(o["detail"])
            o["message"] != null -> errMessage(o["message"])
            else -> body.take(300)
        }
        val full = if (body.contains("terms_not_accepted")) "terms_not_accepted" else code
        return ApiException(status, full, msg)
    }

    /**
     * Sohbet isteği. [onEvent] arka plan iş parçacığından çağrılır.
     * Akış kapalıysa ya da sunucu düz JSON döndürürse yanıt tek seferde gelir.
     */
    suspend fun chat(p: ChatParams, messages: JsonArray, onEvent: (Ev) -> Unit) {
        withContext(Dispatchers.IO) {
            var includeUsage = p.stream
            var tries = 0
            while (true) {
                try {
                    execute(p, messages, includeUsage, onEvent)
                    break
                } catch (e: ApiException) {
                    // Bazı geçitler stream_options'ı tanımaz: bir kez onsuz dene
                    if (tries == 0 && includeUsage && (e.status == 400 || e.status == 422) &&
                        e.message.orEmpty().contains("stream_options", ignoreCase = true)
                    ) {
                        includeUsage = false
                        tries++
                        continue
                    }
                    throw e
                }
            }
        }
    }

    /** Akışsız tek yanıt (başlık üretimi gibi küçük işler). */
    suspend fun complete(p: ChatParams, messages: JsonArray): String {
        val sb = StringBuilder()
        chat(ChatParams(p.base, p.key, p.model, p.temperature, p.maxTokens, false), messages) { ev ->
            if (ev is Ev.Text) sb.append(ev.s)
        }
        return sb.toString()
    }

    private suspend fun execute(p: ChatParams, messages: JsonArray, includeUsage: Boolean, onEvent: (Ev) -> Unit) {
        val body = buildJsonObject {
            put("model", p.model)
            put("messages", messages)
            put("stream", p.stream)
            put("temperature", p.temperature.toDouble())
            if (p.maxTokens > 0) put("max_tokens", p.maxTokens)
            if (p.stream && includeUsage) put("stream_options", buildJsonObject { put("include_usage", true) })
        }
        val request = builder(p.base, p.key, "/chat/completions")
            .post(body.toString().toRequestBody(JSON_TYPE))
            .build()
        val call = client.newCall(request)
        val handle = currentCoroutineContext()[Job]?.invokeOnCompletion { cause ->
            if (cause != null) call.cancel()
        }
        try {
            call.execute().use { resp ->
                val rb = resp.body
                if (!resp.isSuccessful) {
                    throw parseError(resp.code, rb?.string().orEmpty())
                }
                val ct = resp.header("Content-Type").orEmpty()
                if (rb == null) throw ApiException(resp.code, "", "Boş yanıt")
                if (!p.stream || (ct.contains("json", true) && !ct.contains("event-stream", true))) {
                    parseFull(rb.string(), onEvent)
                    return
                }
                val src = rb.source()
                while (true) {
                    val line = src.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val d = line.substring(5).trim()
                    if (d.isEmpty()) continue
                    if (d == "[DONE]") break
                    handleChunk(d, onEvent)
                }
            }
        } catch (e: IOException) {
            if (!currentCoroutineContext().isActive) throw CancellationException("durduruldu")
            throw e
        } finally {
            handle?.dispose()
        }
    }

    private fun usageOf(o: JsonObject, onEvent: (Ev) -> Unit) {
        val u = o["usage"] as? JsonObject ?: return
        val pt = u["prompt_tokens"]?.jsonPrimitive?.intOrNull ?: 0
        val ct = u["completion_tokens"]?.jsonPrimitive?.intOrNull ?: 0
        if (pt > 0 || ct > 0) onEvent(Ev.Usage(pt, ct))
    }

    private fun handleChunk(d: String, onEvent: (Ev) -> Unit) {
        val o = runCatching { parser.parseToJsonElement(d).jsonObject }.getOrNull() ?: return
        o["error"]?.let { throw ApiException(0, errCode(it), errMessage(it)) }
        val choice = (o["choices"] as? JsonArray)?.firstOrNull() as? JsonObject
        val delta = choice?.get("delta") as? JsonObject
        if (delta != null) {
            val think = delta["reasoning_content"].str() ?: delta["reasoning"].str()
            if (!think.isNullOrEmpty()) onEvent(Ev.Think(think))
            val text = delta["content"].str()
            if (!text.isNullOrEmpty()) onEvent(Ev.Text(text))
        }
        usageOf(o, onEvent)
    }

    private fun parseFull(txt: String, onEvent: (Ev) -> Unit) {
        val o = runCatching { parser.parseToJsonElement(txt).jsonObject }.getOrNull()
            ?: throw ApiException(200, "", "Sunucu beklenmeyen bir yanıt döndürdü: ${txt.take(200)}")
        o["error"]?.let { throw ApiException(0, errCode(it), errMessage(it)) }
        val choice = (o["choices"] as? JsonArray)?.firstOrNull() as? JsonObject
        val msg = choice?.get("message") as? JsonObject
        val think = msg?.get("reasoning_content").str() ?: msg?.get("reasoning").str()
        if (!think.isNullOrEmpty()) onEvent(Ev.Think(think))
        val text = msg?.get("content").str()
        if (!text.isNullOrEmpty()) onEvent(Ev.Text(text))
        usageOf(o, onEvent)
    }

    /** GET /models: kullanılabilir model kimlikleri. */
    suspend fun models(base: String, key: String): List<String> = withContext(Dispatchers.IO) {
        val call = client.newCall(builder(base, key, "/models").get().build())
        val handle = currentCoroutineContext()[Job]?.invokeOnCompletion { if (it != null) call.cancel() }
        try {
            call.execute().use { resp ->
                val txt = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw parseError(resp.code, txt)
                val arr = runCatching { parser.parseToJsonElement(txt).jsonObject["data"]?.jsonArray }.getOrNull()
                    ?: throw ApiException(200, "", "Model listesi okunamadı")
                arr.mapNotNull { (it as? JsonObject)?.get("id").str() }.sorted()
            }
        } finally {
            handle?.dispose()
        }
    }

    /** İlk kullanımda gereken kullanım şartları onayı. */
    suspend fun acceptTerms(base: String, key: String) = withContext(Dispatchers.IO) {
        val body = buildJsonObject { put("version", 1) }.toString().toRequestBody(JSON_TYPE)
        client.newCall(builder(base, key, "/terms/accept").post(body).build()).execute().use { resp ->
            if (!resp.isSuccessful) throw parseError(resp.code, resp.body?.string().orEmpty())
        }
    }
}
