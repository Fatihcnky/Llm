package com.example.evrenchat.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val AccentNames = listOf("Mor", "Mavi", "Yeşil", "Turuncu", "Pembe", "Camgöbeği")
val AccentColors = listOf(
    Color(0xFF7C5CFF), Color(0xFF2F7BFF), Color(0xFF1FA971),
    Color(0xFFE8801A), Color(0xFFE0457B), Color(0xFF12A6B8),
)
val ThemeModeNames = listOf("Koyu", "Aydınlık", "Sistem")

@Composable
fun AppTheme(mode: Int, accentIndex: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        0 -> true
        1 -> false
        else -> isSystemInDarkTheme()
    }
    val accent = AccentColors[accentIndex.coerceIn(0, AccentColors.lastIndex)]
    val scheme = if (dark) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.28f).compositeOver(Color(0xFF16181D)),
            onPrimaryContainer = Color(0xFFF2F2F7),
            secondaryContainer = accent.copy(alpha = 0.22f).compositeOver(Color(0xFF16181D)),
            onSecondaryContainer = Color(0xFFF2F2F7),
            background = Color(0xFF0E0F13),
            onBackground = Color(0xFFE9EAEE),
            surface = Color(0xFF0E0F13),
            onSurface = Color(0xFFE9EAEE),
            surfaceVariant = Color(0xFF23262D),
            onSurfaceVariant = Color(0xFFB4B8C2),
            outline = Color(0xFF5B606B),
            surfaceContainerLowest = Color(0xFF0A0B0E),
            surfaceContainerLow = Color(0xFF14161B),
            surfaceContainer = Color(0xFF181A20),
            surfaceContainerHigh = Color(0xFF1E2128),
            surfaceContainerHighest = Color(0xFF262A32),
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.16f).compositeOver(Color.White),
            onPrimaryContainer = Color(0xFF14151A),
            secondaryContainer = accent.copy(alpha = 0.14f).compositeOver(Color.White),
            onSecondaryContainer = Color(0xFF14151A),
            background = Color(0xFFF8F8FB),
            onBackground = Color(0xFF14151A),
            surface = Color(0xFFF8F8FB),
            onSurface = Color(0xFF14151A),
            surfaceVariant = Color(0xFFE6E7EE),
            onSurfaceVariant = Color(0xFF4A4D58),
            outline = Color(0xFF8A8E9A),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = Color(0xFFF2F3F8),
            surfaceContainer = Color(0xFFEDEEF4),
            surfaceContainerHigh = Color(0xFFE7E8EF),
            surfaceContainerHighest = Color(0xFFE0E2EA),
        )
    }
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
        val c = WindowCompat.getInsetsController(window, view)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
        window.statusBarColor = Color.Transparent.toArgb()
        window.navigationBarColor = Color.Transparent.toArgb()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

private fun Color.compositeOver(bg: Color): Color {
    val a = alpha
    return Color(
        red = red * a + bg.red * (1 - a),
        green = green * a + bg.green * (1 - a),
        blue = blue * a + bg.blue * (1 - a),
        alpha = 1f,
    )
}
