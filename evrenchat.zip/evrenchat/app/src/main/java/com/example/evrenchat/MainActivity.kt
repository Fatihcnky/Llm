package com.example.evrenchat

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.evrenchat.ui.AppTheme
import com.example.evrenchat.ui.ChatScreen
import com.example.evrenchat.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)
        setContent {
            val s by vm.settings.collectAsStateWithLifecycle()
            AppTheme(s.themeMode, s.accent) {
                val screen by vm.screen.collectAsStateWithLifecycle()
                val notice by vm.notice.collectAsStateWithLifecycle()
                val ctx = LocalContext.current
                LaunchedEffect(notice) {
                    notice?.let {
                        Toast.makeText(ctx, it, Toast.LENGTH_LONG).show()
                        vm.notice.value = null
                    }
                }
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    when (screen) {
                        Screen.Chat -> ChatScreen(vm)
                        Screen.Settings -> SettingsScreen(vm)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            i.getStringExtra(Intent.EXTRA_TEXT)?.let {
                vm.incoming.value = it
                vm.screen.value = Screen.Chat
            }
        }
    }
}
