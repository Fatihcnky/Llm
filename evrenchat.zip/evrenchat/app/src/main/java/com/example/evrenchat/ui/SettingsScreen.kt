@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.evrenchat.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.evrenchat.AppSettings
import com.example.evrenchat.ChatViewModel
import com.example.evrenchat.DEFAULT_BASE
import com.example.evrenchat.DEFAULT_MODEL
import com.example.evrenchat.Persona
import com.example.evrenchat.Screen
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: ChatViewModel) {
    val saved by vm.settings.collectAsStateWithLifecycle()
    val savedPersonas by vm.personas.collectAsStateWithLifecycle()
    val models by vm.models.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var d by remember { mutableStateOf(saved) }
    val plist = remember { mutableStateListOf<Persona>().apply { addAll(savedPersonas) } }
    var showKey by remember { mutableStateOf(false) }
    var modelMenu by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var testMsg by remember { mutableStateOf<String?>(null) }
    var needTerms by remember { mutableStateOf(false) }
    var editPersona by remember { mutableStateOf<Persona?>(null) }
    var confirmWipe by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }

    val dirty = d != saved || plist.toList() != savedPersonas

    fun save() {
        val list = plist.toList().ifEmpty { listOf(Persona("none", "Sistem istemi yok", "")) }
        val persona = if (list.any { it.id == d.persona }) d.persona else list.first().id
        vm.saveSettings(d.copy(persona = persona), list)
        d = vm.settings.value
    }

    fun leave() {
        if (dirty) confirmExit = true else vm.screen.value = Screen.Chat
    }
    BackHandler { leave() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                title = { Text("Ayarlar") },
                navigationIcon = {
                    IconButton(onClick = { leave() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri") }
                },
            )
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        if (dirty) "Kaydedilmemiş değişiklikler var" else "✓ Tüm ayarlar kayıtlı",
                        color = if (dirty) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp, modifier = Modifier.weight(1f),
                    )
                    Button(onClick = { save() }, enabled = dirty) { Text("Kaydet") }
                }
            }
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).consumeWindowInsets(pad).imePadding().fillMaxSize()
                .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // ---------------- Bağlantı
            Section("Bağlantı (Evren AI)")
            OutlinedTextField(
                d.baseUrl, { d = d.copy(baseUrl = it) }, label = { Text("API adresi") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                supportingText = { Text("Varsayılan: $DEFAULT_BASE") },
            )
            OutlinedTextField(
                d.apiKey, { d = d.copy(apiKey = it); needTerms = false }, label = { Text("API anahtarı (evren_llm_…)") }, singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { showKey = !showKey }) {
                        Icon(if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = "Göster/gizle")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    enabled = !testing && d.apiKey.isNotBlank(),
                    onClick = {
                        testing = true
                        testMsg = null
                        scope.launch {
                            vm.loadModels(d.baseUrl, d.apiKey)
                                .onSuccess { testMsg = "✓ Bağlantı çalışıyor. ${it.size} model bulundu."; needTerms = false }
                                .onFailure {
                                    testMsg = "✗ ${it.message}"
                                    needTerms = (it.message ?: "").contains("şartları")
                                }
                            testing = false
                        }
                    },
                ) { Text(if (testing) "Deneniyor…" else "Bağlantıyı test et / modelleri getir") }
            }
            testMsg?.let {
                Text(it, fontSize = 13.sp, color = if (it.startsWith("✓")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
            if (needTerms) {
                Button(onClick = {
                    scope.launch {
                        vm.acceptTerms(d.baseUrl, d.apiKey)
                            .onSuccess { testMsg = "✓ Kullanım şartları kabul edildi. Bağlantıyı tekrar test et."; needTerms = false }
                            .onFailure { testMsg = "✗ ${it.message}" }
                    }
                }) { Text("Kullanım şartlarını kabul et") }
            }

            // ---------------- Model
            Section("Model")
            OutlinedTextField(
                d.model, { d = d.copy(model = it) }, label = { Text("Model adı") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                supportingText = { Text("Önerilen: $DEFAULT_MODEL  •  Görsel için: qwen3-vl-30b") },
            )
            Box {
                OutlinedButton(onClick = { modelMenu = true }, enabled = models.isNotEmpty()) {
                    Text(if (models.isEmpty()) "Listeden seç (önce bağlantıyı test et)" else "Listeden seç (${models.size})")
                }
                DropdownMenu(expanded = modelMenu, onDismissRequest = { modelMenu = false }) {
                    models.forEach { m ->
                        DropdownMenuItem(
                            text = { Text(m + if (m == d.model) "  ✓" else "") },
                            onClick = { d = d.copy(model = m); modelMenu = false },
                        )
                    }
                }
            }

            // ---------------- Üretim
            Section("Yanıt ayarları")
            Text("Yaratıcılık (sıcaklık): ${"%.1f".format(d.temperature)}", fontSize = 14.sp)
            Slider(d.temperature, { d = d.copy(temperature = (it * 10).roundToInt() / 10f) }, valueRange = 0f..2f)
            OutlinedTextField(
                if (d.maxTokens == 0) "" else d.maxTokens.toString(),
                { v -> d = d.copy(maxTokens = v.filter { c -> c.isDigit() }.take(6).toIntOrNull() ?: 0) },
                label = { Text("En fazla yanıt uzunluğu (jeton)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                supportingText = { Text("Boş = sunucu varsayılanı (sınırsız gibi)") },
                modifier = Modifier.fillMaxWidth(),
            )
            Text("Modele gönderilen geçmiş: son ${d.history} mesaj", fontSize = 14.sp)
            Slider(d.history.toFloat(), { d = d.copy(history = it.roundToInt()) }, valueRange = 2f..100f)
            SwitchRow("Yanıtı canlı akıt (yazdıkça göster)", d.stream) { d = d.copy(stream = it) }
            SwitchRow("Sohbet başlığını yapay zekâ üretsin", d.autoTitle) { d = d.copy(autoTitle = it) }

            // ---------------- Roller
            Section("Roller (sistem istemleri)")
            Text(
                "Seçili rol yeni sohbetlerde varsayılan olur. Sohbet içinde üstteki ayar simgesinden değiştirebilirsin.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            plist.forEach { p ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { d = d.copy(persona = p.id) },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = d.persona == p.id, onClick = { d = d.copy(persona = p.id) })
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold)
                        if (p.prompt.isNotBlank()) {
                            Text(p.prompt, fontSize = 12.sp, maxLines = 2, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    IconButton(onClick = { editPersona = p }) { Icon(Icons.Filled.Edit, contentDescription = "Düzenle") }
                    IconButton(onClick = { plist.remove(p) }, enabled = plist.size > 1) { Icon(Icons.Filled.Delete, contentDescription = "Sil") }
                }
            }
            OutlinedButton(onClick = { editPersona = Persona(UUID.randomUUID().toString(), "", "") }) { Text("+ Yeni rol ekle") }

            // ---------------- Görünüm
            Section("Görünüm")
            Text("Tema", fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeModeNames.forEachIndexed { i, n ->
                    FilterChip(selected = d.themeMode == i, onClick = { d = d.copy(themeMode = i) }, label = { Text(n) })
                }
            }
            Text("Vurgu rengi", fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AccentColors.forEachIndexed { i, c ->
                    Box(
                        Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(if (d.accent == i) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                            .clickable { d = d.copy(accent = i) },
                        contentAlignment = Alignment.Center,
                    ) { if (d.accent == i) Icon(Icons.Filled.Check, contentDescription = AccentNames[i], tint = Color.White) }
                }
            }
            Text("Yazı boyutu: %${(d.fontScale * 100).roundToInt()}", fontSize = 14.sp)
            Slider(d.fontScale, { d = d.copy(fontScale = (it * 20).roundToInt() / 20f) }, valueRange = 0.85f..1.5f)

            // ---------------- Veri
            Section("Veri")
            OutlinedButton(onClick = { confirmWipe = true }) { Text("Tüm sohbetleri sil") }
            Text(
                "Sohbetler yalnızca bu cihazda saklanır. API anahtarı da cihazdaki ayarlarda durur.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.size(24.dp))
        }
    }

    editPersona?.let { p ->
        var name by remember(p.id) { mutableStateOf(p.name) }
        var prompt by remember(p.id) { mutableStateOf(p.prompt) }
        AlertDialog(
            onDismissRequest = { editPersona = null },
            title = { Text(if (plist.any { it.id == p.id }) "Rolü düzenle" else "Yeni rol") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Ad") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(prompt, { prompt = it }, label = { Text("Sistem istemi") }, minLines = 4, maxLines = 10, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank(),
                    onClick = {
                        val np = Persona(p.id, name.trim(), prompt.trim())
                        val i = plist.indexOfFirst { it.id == p.id }
                        if (i >= 0) plist[i] = np else plist.add(np)
                        editPersona = null
                    },
                ) { Text("Tamam") }
            },
            dismissButton = { TextButton(onClick = { editPersona = null }) { Text("Vazgeç") } },
        )
    }

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Tüm sohbetler silinsin mi?") },
            text = { Text("Bu işlem geri alınamaz.") },
            confirmButton = { TextButton(onClick = { vm.deleteAllChats(); confirmWipe = false }) { Text("Sil") } },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("Vazgeç") } },
        )
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Kaydedilmemiş değişiklikler") },
            text = { Text("Ayarlar kaydedilmedi. Ne yapılsın?") },
            confirmButton = { TextButton(onClick = { save(); confirmExit = false; vm.screen.value = Screen.Chat }) { Text("Kaydet ve çık") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmExit = false }) { Text("Vazgeç") }
                    TextButton(onClick = { confirmExit = false; vm.screen.value = Screen.Chat }) { Text("Kaydetmeden çık") }
                }
            },
        )
    }
}

@Composable
private fun Section(title: String) {
    Column(Modifier.padding(top = 14.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        HorizontalDivider(Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = value, onCheckedChange = onChange)
    }
}
