package com.example.evrenchat

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Sohbetler uygulama klasöründe JSON dosyaları olarak saklanır (her sohbet ayrı dosya + küçük bir dizin). */
class Store(ctx: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val dir = File(ctx.filesDir, "chats").apply { mkdirs() }
    val imgDir = File(ctx.filesDir, "img").apply { mkdirs() }
    private val indexFile = File(ctx.filesDir, "index.json")

    private fun fileOf(id: String) = File(dir, "$id.json")

    private fun writeAtomic(f: File, text: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(f)) {
            f.writeText(text)
            tmp.delete()
        }
    }

    @Synchronized
    private fun writeIndex(list: List<ConvMeta>) {
        runCatching { writeAtomic(indexFile, json.encodeToString(list)) }
    }

    @Synchronized
    fun loadIndex(): List<ConvMeta> {
        val fromFile = runCatching { json.decodeFromString<List<ConvMeta>>(indexFile.readText()) }.getOrNull()
        if (fromFile != null) return fromFile
        val rebuilt = dir.listFiles().orEmpty().filter { it.name.endsWith(".json") }.mapNotNull { f ->
            runCatching { json.decodeFromString<Conv>(f.readText()) }.getOrNull()
                ?.let { ConvMeta(it.id, it.title, it.updated, it.pinned) }
        }
        writeIndex(rebuilt)
        return rebuilt
    }

    fun load(id: String): Conv? =
        runCatching { json.decodeFromString<Conv>(fileOf(id).readText()) }.getOrNull()

    @Synchronized
    fun save(c: Conv): List<ConvMeta> {
        runCatching { writeAtomic(fileOf(c.id), json.encodeToString(c)) }
        val idx = loadIndex().filter { it.id != c.id } + ConvMeta(c.id, c.title, c.updated, c.pinned)
        writeIndex(idx)
        return idx
    }

    @Synchronized
    fun delete(id: String): List<ConvMeta> {
        load(id)?.msgs?.flatMap { it.atts }?.forEach { a -> a.file?.let { File(imgDir, it).delete() } }
        fileOf(id).delete()
        val idx = loadIndex().filter { it.id != id }
        writeIndex(idx)
        return idx
    }

    @Synchronized
    fun deleteAll(): List<ConvMeta> {
        dir.listFiles()?.forEach { it.delete() }
        imgDir.listFiles()?.forEach { it.delete() }
        writeIndex(emptyList())
        return emptyList()
    }

    /** Başlığında ya da mesajlarında [q] geçen sohbetlerin kimlikleri. */
    fun search(q: String): Set<String> {
        val needle = q.trim()
        if (needle.isEmpty()) return emptySet()
        val out = HashSet<String>()
        dir.listFiles().orEmpty().forEach { f ->
            if (f.name.endsWith(".json") && runCatching { f.readText().contains(needle, ignoreCase = true) }.getOrDefault(false)) {
                out += f.name.removeSuffix(".json")
            }
        }
        return out
    }

    fun exportMarkdown(c: Conv): String {
        val sb = StringBuilder()
        sb.append("# ").append(c.title).append("\n\n")
        val fmt = SimpleDateFormat("d MMMM yyyy HH:mm", Locale("tr"))
        sb.append("_").append(fmt.format(Date(c.created))).append("_\n\n")
        for (m in c.msgs) {
            if (m.role == "user") {
                sb.append("## 🧑 Sen\n\n").append(m.content).append("\n\n")
                m.atts.forEach { sb.append("📎 ").append(it.name).append("\n\n") }
            } else if (m.content.isNotBlank()) {
                sb.append("## 🤖 ").append(m.model.ifBlank { "Asistan" }).append("\n\n").append(m.content).append("\n\n")
            }
        }
        return sb.toString().trimEnd() + "\n"
    }
}
