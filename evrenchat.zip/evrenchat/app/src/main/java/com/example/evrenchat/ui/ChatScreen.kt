@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.evrenchat.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.evrenchat.Att
import com.example.evrenchat.ChatViewModel
import com.example.evrenchat.ConvMeta
import com.example.evrenchat.Msg
import com.example.evrenchat.Screen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private val Suggestions = listOf(
    "Bir Kotlin fonksiyonu yazmama yardım et",
    "Bu metni özetle ve ana fikirleri çıkar:",
    "Aşağıdaki metni İngilizceye çevir:",
    "Bana 5 fikir öner: ",
)

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val chat by vm.chat.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val generating by vm.generating.collectAsStateWithLifecycle()
    val personas by vm.personas.collectAsStateWithLifecycle()
    val index by vm.index.collectAsStateWithLifecycle()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val incoming by vm.incoming.collectAsStateWithLifecycle()
    val termsNeeded by vm.termsNeeded.collectAsStateWithLifecycle()
    val hits by vm.searchHits.collectAsStateWithLifecycle()

    var input by rememberSaveable { mutableStateOf("") }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var moreMenu by remember { mutableStateOf(false) }
    var personaMenu by remember { mutableStateOf(false) }
    var renameFor by remember { mutableStateOf<ConvMeta?>(null) }
    var deleteFor by remember { mutableStateOf<ConvMeta?>(null) }
    var editing by remember { mutableStateOf<Msg?>(null) }
    var drawerQuery by remember { mutableStateOf("") }

    LaunchedEffect(incoming) {
        incoming?.let {
            input = if (input.isBlank()) it else input + "\n" + it
            vm.incoming.value = null
        }
    }
    BackHandler(drawer.isOpen) { scope.launch { drawer.close() } }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let(vm::addImage) }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(vm::addFile) }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !t.isNullOrBlank()) {
            input = if (input.isBlank()) t else input.trimEnd() + " " + t
        }
    }

    val personaId = chat.persona.ifBlank { settings.persona }
    val personaName = personas.firstOrNull { it.id == personaId }?.name ?: "Sistem istemi yok"
    val msgs = chat.msgs

    fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        ctx.startActivity(Intent.createChooser(i, "Paylaş"))
    }

    fun copy(text: String) {
        clipboard.setText(AnnotatedString(text))
        Toast.makeText(ctx, "Kopyalandı", Toast.LENGTH_SHORT).show()
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                DrawerBody(
                    chats = index,
                    currentId = chat.id,
                    hits = hits,
                    query = drawerQuery,
                    onQuery = { drawerQuery = it; vm.search(it) },
                    onNew = { vm.newChat(); scope.launch { drawer.close() } },
                    onOpen = { vm.openChat(it); scope.launch { drawer.close() } },
                    onRename = { renameFor = it },
                    onPin = { vm.pinChat(it.id, !it.pinned) },
                    onDelete = { deleteFor = it },
                    onSettings = { scope.launch { drawer.close() }; vm.screen.value = Screen.Settings },
                )
            }
        },
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Sohbetler")
                        }
                    },
                    title = {
                        Column {
                            Text(chat.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${settings.model} • $personaName",
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { vm.newChat() }) { Icon(Icons.Filled.Add, contentDescription = "Yeni sohbet") }
                        Box {
                            IconButton(onClick = { personaMenu = true }) { Icon(Icons.Filled.Tune, contentDescription = "Rol / sistem istemi") }
                            DropdownMenu(expanded = personaMenu, onDismissRequest = { personaMenu = false }) {
                                personas.forEach { p ->
                                    DropdownMenuItem(
                                        text = { Text(p.name + if (p.id == personaId) "  ✓" else "") },
                                        onClick = { vm.setPersona(p.id); personaMenu = false },
                                    )
                                }
                            }
                        }
                        Box {
                            IconButton(onClick = { moreMenu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Daha fazla") }
                            DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Yeniden adlandır") },
                                    enabled = msgs.isNotEmpty(),
                                    onClick = { moreMenu = false; renameFor = ConvMeta(chat.id, chat.title, chat.updated, chat.pinned) },
                                )
                                DropdownMenuItem(
                                    text = { Text("Sohbeti paylaş / dışa aktar") },
                                    enabled = msgs.isNotEmpty(),
                                    onClick = { moreMenu = false; share(vm.exportChat()) },
                                )
                                DropdownMenuItem(
                                    text = { Text("Sohbeti sil") },
                                    enabled = msgs.isNotEmpty(),
                                    onClick = { moreMenu = false; deleteFor = ConvMeta(chat.id, chat.title, chat.updated, chat.pinned) },
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("Ayarlar") },
                                    onClick = { moreMenu = false; vm.screen.value = Screen.Settings },
                                )
                            }
                        }
                    },
                )
            },
        ) { pad ->
            Column(Modifier.padding(pad).consumeWindowInsets(pad).imePadding().fillMaxSize()) {
                val listState = rememberLazyListState()
                LaunchedEffect(msgs.size, chat.id) { listState.scrollToItem(0) }
                val reversed = remember(msgs) { msgs.asReversed() }

                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (msgs.isEmpty()) {
                        EmptyState(
                            model = settings.model,
                            hasKey = settings.apiKey.isNotBlank(),
                            onSettings = { vm.screen.value = Screen.Settings },
                            onPick = { input = it },
                        )
                    } else {
                        LazyColumn(
                            state = listState,
                            reverseLayout = true,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(18.dp),
                        ) {
                            items(reversed, key = { it.id }) { m ->
                                val isLast = m.id == msgs.last().id
                                if (m.role == "user") {
                                    UserMessage(
                                        m = m,
                                        scale = settings.fontScale,
                                        imgDir = vm.store.imgDir,
                                        canEdit = !generating,
                                        onCopy = { copy(m.content) },
                                        onEdit = { editing = m },
                                        onDelete = { vm.deleteMsg(m.id) },
                                    )
                                } else {
                                    AssistantMessage(
                                        m = m,
                                        scale = settings.fontScale,
                                        streaming = generating && isLast,
                                        isLast = isLast,
                                        busy = generating,
                                        onCopy = { copy(m.content) },
                                        onShare = { share(m.content) },
                                        onRegenerate = { vm.regenerate() },
                                        onDelete = { vm.deleteMsg(m.id) },
                                    )
                                }
                            }
                        }
                    }
                    if (listState.firstVisibleItemIndex > 1) {
                        SmallFloatingActionButton(
                            onClick = { scope.launch { listState.animateScrollToItem(0) } },
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp),
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        ) { Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "En alta git") }
                    }
                }

                Composer(
                    input = input,
                    onInput = { input = it },
                    pending = pending,
                    generating = generating,
                    model = settings.model,
                    onSend = {
                        val t = input
                        input = ""
                        vm.send(t)
                    },
                    onStop = { vm.stop() },
                    onImage = { pickImage.launch("image/*") },
                    onFile = { pickFile.launch(arrayOf("*/*")) },
                    onVoice = {
                        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                        }
                        try {
                            voice.launch(i)
                        } catch (e: ActivityNotFoundException) {
                            Toast.makeText(ctx, "Bu cihazda sesle yazma bulunamadı", Toast.LENGTH_LONG).show()
                        }
                    },
                    onRemove = { vm.removePending(it) },
                )
            }
        }
    }

    renameFor?.let { meta ->
        var text by remember(meta.id) { mutableStateOf(meta.title) }
        AlertDialog(
            onDismissRequest = { renameFor = null },
            title = { Text("Sohbeti yeniden adlandır") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { vm.renameChat(meta.id, text); renameFor = null }) { Text("Kaydet") } },
            dismissButton = { TextButton(onClick = { renameFor = null }) { Text("Vazgeç") } },
        )
    }

    deleteFor?.let { meta ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text("Sohbet silinsin mi?") },
            text = { Text("“${meta.title}” kalıcı olarak silinecek.") },
            confirmButton = { TextButton(onClick = { vm.deleteChat(meta.id); deleteFor = null }) { Text("Sil") } },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Vazgeç") } },
        )
    }

    editing?.let { m ->
        var text by remember(m.id) { mutableStateOf(m.content) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Mesajı düzenle") },
            text = {
                Column {
                    OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth(), maxLines = 10)
                    Text(
                        "Gönderince bu mesajdan sonraki konuşma silinir ve yanıt yeniden üretilir.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { vm.editResend(m.id, text); editing = null }) { Text("Gönder") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Vazgeç") } },
        )
    }

    if (termsNeeded) {
        val scope2 = rememberCoroutineScope()
        AlertDialog(
            onDismissRequest = { vm.termsNeeded.value = false },
            title = { Text("Kullanım şartları") },
            text = {
                Text(
                    "Evren LLM geçidi, yeni bir anahtarla ilk kullanımda kullanım şartlarının kabul edilmesini istiyor. " +
                        "Kabul edip kaldığın yerden devam edelim mi?"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope2.launch {
                        val s = vm.settings.value
                        vm.acceptTerms(s.baseUrl, s.apiKey)
                            .onSuccess { vm.regenerate() }
                            .onFailure { vm.notice.value = it.message }
                    }
                }) { Text("Kabul et") }
            },
            dismissButton = { TextButton(onClick = { vm.termsNeeded.value = false }) { Text("Vazgeç") } },
        )
    }
}

// ---------------------------------------------------------------- Kenar çubuğu

@Composable
private fun DrawerBody(
    chats: List<ConvMeta>,
    currentId: String,
    hits: Set<String>?,
    query: String,
    onQuery: (String) -> Unit,
    onNew: () -> Unit,
    onOpen: (String) -> Unit,
    onRename: (ConvMeta) -> Unit,
    onPin: (ConvMeta) -> Unit,
    onDelete: (ConvMeta) -> Unit,
    onSettings: () -> Unit,
) {
    val list = remember(chats, hits, query) {
        val base = if (query.isBlank()) chats else chats.filter {
            it.title.contains(query, ignoreCase = true) || (hits?.contains(it.id) == true)
        }
        base.sortedWith(compareByDescending<ConvMeta> { it.pinned }.thenByDescending { it.updated })
    }
    Column(Modifier.fillMaxSize()) {
        Text(
            "Evren Sohbet", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
        )
        Button(
            onClick = onNew,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Text("  Yeni sohbet")
        }
        OutlinedTextField(
            value = query, onValueChange = onQuery, singleLine = true,
            placeholder = { Text("Sohbetlerde ara") },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        )
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) {
            if (list.isEmpty()) {
                item {
                    Text(
                        if (query.isBlank()) "Henüz sohbet yok" else "Eşleşen sohbet yok",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }
            items(list, key = { it.id }) { c ->
                var menu by remember { mutableStateOf(false) }
                NavigationDrawerItem(
                    label = { Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    selected = c.id == currentId,
                    onClick = { onOpen(c.id) },
                    icon = { if (c.pinned) Icon(Icons.Filled.PushPin, contentDescription = "Sabit", modifier = Modifier.size(18.dp)) },
                    badge = {
                        Box {
                            IconButton(onClick = { menu = true }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Filled.MoreVert, contentDescription = "Seçenekler")
                            }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(text = { Text(if (c.pinned) "Sabitlemeyi kaldır" else "Sabitle") }, onClick = { menu = false; onPin(c) })
                                DropdownMenuItem(text = { Text("Yeniden adlandır") }, onClick = { menu = false; onRename(c) })
                                DropdownMenuItem(text = { Text("Sil") }, onClick = { menu = false; onDelete(c) })
                            }
                        }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                )
            }
        }
        HorizontalDivider()
        NavigationDrawerItem(
            label = { Text("Ayarlar") },
            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
            selected = false,
            onClick = onSettings,
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding).padding(vertical = 4.dp),
        )
    }
}

// ---------------------------------------------------------------- Boş ekran

@Composable
private fun EmptyState(model: String, hasKey: Boolean, onSettings: () -> Unit, onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center,
        ) { Text("E", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold) }
        Text(
            "Nasıl yardımcı olabilirim?", style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp),
        )
        Text(model, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp, bottom = 20.dp))
        if (!hasKey) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Başlamak için Evren API anahtarını gir", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Anahtar evren_llm_ ile başlar. Ayarlar > Bağlantı bölümüne yapıştır.",
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp),
                    )
                    Button(onClick = onSettings, modifier = Modifier.padding(top = 10.dp)) { Text("Ayarlara git") }
                }
            }
        }
        Suggestions.forEach { s ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp)).clickable { onPick(s) },
            ) {
                Text(s, modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

// ---------------------------------------------------------------- Mesajlar

@Composable
private fun UserMessage(
    m: Msg,
    scale: Float,
    imgDir: File,
    canEdit: Boolean,
    onCopy: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        m.atts.forEach { a ->
            if (a.kind == "image" && a.file != null) {
                AsyncImage(
                    model = File(imgDir, a.file),
                    contentDescription = a.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(160.dp).clip(RoundedCornerShape(14.dp)),
                )
            } else {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text(a.name, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 220.dp).padding(start = 6.dp))
                }
            }
        }
        if (m.content.isNotBlank()) {
            Box {
                Surface(
                    shape = RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier
                        .widthIn(max = 320.dp)
                        .clip(RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp))
                        .combinedClickable(onClick = {}, onLongClick = { menu = true }),
                ) {
                    Text(
                        m.content,
                        fontSize = 16.sp * scale,
                        lineHeight = 23.sp * scale,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    )
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Kopyala") }, onClick = { menu = false; onCopy() })
                    if (canEdit) {
                        DropdownMenuItem(text = { Text("Düzenle ve yeniden gönder") }, onClick = { menu = false; onEdit() })
                        DropdownMenuItem(text = { Text("Sil") }, onClick = { menu = false; onDelete() })
                    }
                }
            }
        }
    }
}

@Composable
private fun AssistantMessage(
    m: Msg,
    scale: Float,
    streaming: Boolean,
    isLast: Boolean,
    busy: Boolean,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onRegenerate: () -> Unit,
    onDelete: () -> Unit,
) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (m.reasoning.isNotBlank()) ReasoningBlock(m, streaming)
        if (m.content.isNotBlank()) {
            SelectionContainer { Markdown(m.content, scale = scale) }
        } else if (streaming && m.reasoning.isBlank()) {
            TypingDots()
        }
        if (m.err.isNotBlank()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.errorContainer,
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(m.err, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 14.sp)
                    if (isLast && !busy) {
                        TextButton(onClick = onRegenerate) { Text("Tekrar dene") }
                    }
                }
            }
        }
        if (!streaming && (m.content.isNotBlank() || m.err.isNotBlank())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (m.content.isNotBlank()) {
                    SmallIcon(Icons.Filled.ContentCopy, "Kopyala", onCopy)
                    SmallIcon(Icons.Filled.Share, "Paylaş", onShare)
                }
                if (isLast && !busy && m.err.isBlank()) SmallIcon(Icons.Filled.Refresh, "Yeniden üret", onRegenerate)
                if (!busy) SmallIcon(Icons.Filled.DeleteOutline, "Sil", onDelete)
                val info = buildString {
                    if (m.promptTokens > 0 || m.completionTokens > 0) append("↑${m.promptTokens} ↓${m.completionTokens} jeton")
                }
                if (info.isNotEmpty()) {
                    Text(
                        info, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 8.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun SmallIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(34.dp)) {
        Icon(icon, contentDescription = desc, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ReasoningBlock(m: Msg, streaming: Boolean) {
    var expanded by rememberSaveable(m.id) { mutableStateOf(false) }
    val open = expanded || (streaming && m.content.isBlank())
    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (streaming && m.content.isBlank()) "Düşünüyor…" else "Düşünce süreci",
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f),
                )
                Icon(
                    if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (open) {
                Text(
                    m.reasoning,
                    fontSize = 13.sp, lineHeight = 19.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .heightIn(max = 260.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
                )
            }
        }
    }
}

@Composable
private fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    val a by t.animateFloat(
        initialValue = 0.25f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "alpha",
    )
    Text("●  ●  ●", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, modifier = Modifier.alpha(a).padding(vertical = 6.dp))
}

// ---------------------------------------------------------------- Yazı alanı

@Composable
private fun Composer(
    input: String,
    onInput: (String) -> Unit,
    pending: List<Att>,
    generating: Boolean,
    model: String,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onImage: () -> Unit,
    onFile: () -> Unit,
    onVoice: () -> Unit,
    onRemove: (Att) -> Unit,
) {
    var attachMenu by remember { mutableStateOf(false) }
    val visionOk = remember(model) {
        val m = model.lowercase()
        m.contains("vl") || m.contains("vision") || m.contains("gpt-4") || m.contains("gemma-3") || m.contains("gemma-4")
    }
    val canSend = input.isNotBlank() || pending.isNotEmpty()
    Surface(
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
    ) {
        Column(Modifier.padding(top = 4.dp)) {
            if (pending.isNotEmpty()) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    pending.forEach { a ->
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                                .padding(start = 10.dp, top = 4.dp, bottom = 4.dp, end = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(if (a.kind == "image") Icons.Filled.Image else Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text(a.name, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp).padding(horizontal = 6.dp))
                            IconButton(onClick = { onRemove(a) }, modifier = Modifier.size(26.dp)) {
                                Icon(Icons.Filled.Close, contentDescription = "Kaldır", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
                if (!visionOk && pending.any { it.kind == "image" }) {
                    Text(
                        "“$model” görsel okuyamaz. Ayarlar'dan qwen3-vl-30b gibi görüntü destekleyen bir model seç.",
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 14.dp),
                    )
                }
            }
            TextField(
                value = input,
                onValueChange = onInput,
                placeholder = { Text("Mesaj yaz…") },
                maxLines = 7,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Default),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box {
                    IconButton(onClick = { attachMenu = true }) { Icon(Icons.Filled.AttachFile, contentDescription = "Ekle") }
                    DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                        DropdownMenuItem(text = { Text("Görsel ekle") }, leadingIcon = { Icon(Icons.Filled.Image, null) }, onClick = { attachMenu = false; onImage() })
                        DropdownMenuItem(text = { Text("Dosya ekle (metin / kod)") }, leadingIcon = { Icon(Icons.Filled.AttachFile, null) }, onClick = { attachMenu = false; onFile() })
                    }
                }
                IconButton(onClick = onVoice) { Icon(Icons.Filled.Mic, contentDescription = "Sesle yaz") }
                Spacer(Modifier.weight(1f))
                if (generating) {
                    FilledIconButton(onClick = onStop) { Icon(Icons.Filled.Stop, contentDescription = "Durdur") }
                } else {
                    FilledIconButton(onClick = onSend, enabled = canSend) { Icon(Icons.Filled.ArrowUpward, contentDescription = "Gönder") }
                }
            }
        }
    }
}
