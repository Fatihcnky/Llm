package com.example.evrenchat

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.SystemClock
import android.provider.OpenableColumns
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class Screen { Chat, Settings }

class ChatViewModel(private val app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("evren", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    val store = Store(app)

    val screen = MutableStateFlow(Screen.Chat)
    val notice = MutableStateFlow<String?>(null)

    val settings = MutableStateFlow(loadSettings())
    val personas = MutableStateFlow(loadPersonas())

    val index = MutableStateFlow(store.loadIndex())
    val chat = MutableStateFlow(emptyChat())
    val generating = MutableStateFlow(false)

    /** Mesaja eklenmeyi bekleyen dosyalar/görseller. */
    val pending = MutableStateFlow<List<Att>>(emptyList())

    /** Başka uygulamadan "Paylaş" ile gelen metin: yazı alanına konur. */
    val incoming = MutableStateFlow<String?>(null)

    /** İlk kullanımda kullanım şartları onayı gerekiyor. */
    val termsNeeded = MutableStateFlow(false)

    /** Arama: boş değilse eşleşen sohbet kimlikleri. */
    val searchHits = MutableStateFlow<Set<String>?>(null)

    val models = MutableStateFlow<List<String>>(emptyList())

    private var job: Job? = null

    // ------------------------------------------------------------------ Ayarlar

    private fun loadSettings() = AppSettings(
        baseUrl = prefs.getString("base_url", DEFAULT_BASE).orEmpty().ifBlank { DEFAULT_BASE },
        apiKey = prefs.getString("api_key", "").orEmpty(),
        model = prefs.getString("model", DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL },
        temperature = prefs.getFloat("temperature", 0.7f),
        maxTokens = prefs.getInt("max_tokens", 0),
        history = prefs.getInt("history", 40),
        stream = prefs.getBoolean("stream", true),
        autoTitle = prefs.getBoolean("auto_title", true),
        themeMode = prefs.getInt("theme_mode", 0).coerceIn(0, 2),
        accent = prefs.getInt("accent", 0).coerceIn(0, 5),
        fontScale = prefs.getFloat("font_scale", 1f),
        persona = prefs.getString("persona", "general").orEmpty(),
    )

    private fun loadPersonas(): List<Persona> =
        prefs.getString("personas", null)
            ?.let { runCatching { json.decodeFromString<List<Persona>>(it) }.getOrNull() }
            ?.takeIf { it.isNotEmpty() }
            ?: DefaultPersonas

    fun saveSettings(s: AppSettings, list: List<Persona>) {
        val clean = s.copy(baseUrl = s.baseUrl.trim().ifBlank { DEFAULT_BASE }, apiKey = s.apiKey.trim(), model = s.model.trim().ifBlank { DEFAULT_MODEL })
        val old = settings.value
        settings.value = clean
        personas.value = list
        prefs.edit()
            .putString("base_url", clean.baseUrl)
            .putString("api_key", clean.apiKey)
            .putString("model", clean.model)
            .putFloat("temperature", clean.temperature)
            .putInt("max_tokens", clean.maxTokens)
            .putInt("history", clean.history)
            .putBoolean("stream", clean.stream)
            .putBoolean("auto_title", clean.autoTitle)
            .putInt("theme_mode", clean.themeMode)
            .putInt("accent", clean.accent)
            .putFloat("font_scale", clean.fontScale)
            .putString("persona", clean.persona)
            .putString("personas", json.encodeToString(list))
            .apply()
        if (old.baseUrl != clean.baseUrl || old.apiKey != clean.apiKey) models.value = emptyList()
        notice.value = "Ayarlar kaydedildi"
    }

    /** Ayarlar ekranı: kaydetmeden önce girilen adres/anahtarla model listesini getirir. */
    suspend fun loadModels(base: String, key: String): Result<List<String>> =
        runCatching { Api.models(base, key) }
            .onSuccess { models.value = it }
            .recoverCatching { throw Exception(friendly(it)) }

    suspend fun acceptTerms(base: String, key: String): Result<Unit> =
        runCatching { Api.acceptTerms(base, key) }
            .onSuccess { termsNeeded.value = false }
            .recoverCatching { throw Exception(friendly(it)) }

    // ------------------------------------------------------------------ Sohbet listesi

    private fun emptyChat() = Conv(id = UUID.randomUUID().toString(), persona = "")

    fun newChat() {
        stop()
        chat.value = emptyChat()
        pending.value = emptyList()
        screen.value = Screen.Chat
    }

    fun openChat(id: String) {
        if (chat.value.id == id) return
        stop()
        viewModelScope.launch {
            val c = withContext(Dispatchers.IO) { store.load(id) }
            if (c != null) {
                chat.value = c
                pending.value = emptyList()
            }
        }
    }

    fun deleteChat(id: String) {
        if (chat.value.id == id) newChat()
        viewModelScope.launch(Dispatchers.IO) { index.value = store.delete(id) }
    }

    fun deleteAllChats() {
        stop()
        chat.value = emptyChat()
        viewModelScope.launch(Dispatchers.IO) { index.value = store.deleteAll() }
    }

    fun renameChat(id: String, title: String) {
        val t = title.trim().ifBlank { return }
        updateStored(id) { it.copy(title = t) }
    }

    fun pinChat(id: String, pinned: Boolean) = updateStored(id) { it.copy(pinned = pinned) }

    fun setPersona(id: String) {
        val c = chat.value
        chat.value = c.copy(persona = id)
        if (c.msgs.isNotEmpty()) persist(chat.value)
    }

    private fun updateStored(id: String, f: (Conv) -> Conv) {
        if (chat.value.id == id) {
            chat.value = f(chat.value)
            if (chat.value.msgs.isNotEmpty()) persist(chat.value)
        } else {
            viewModelScope.launch(Dispatchers.IO) {
                val c = store.load(id) ?: return@launch
                index.value = store.save(f(c))
            }
        }
    }

    fun search(q: String) {
        if (q.isBlank()) {
            searchHits.value = null
            return
        }
        viewModelScope.launch {
            searchHits.value = withContext(Dispatchers.IO) { store.search(q) }
        }
    }

    private fun persist(c: Conv) {
        if (c.msgs.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) { index.value = store.save(c) }
    }

    fun exportChat(): String = store.exportMarkdown(chat.value)

    // ------------------------------------------------------------------ Ekler

    fun addImage(uri: Uri) {
        viewModelScope.launch {
            val att = withContext(Dispatchers.IO) { runCatching { importImage(uri) }.getOrNull() }
            if (att == null) notice.value = "Görsel eklenemedi" else pending.value = pending.value + att
        }
    }

    fun addFile(uri: Uri) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { importText(uri) } }
            r.onSuccess { pending.value = pending.value + it }
            r.onFailure { notice.value = it.message ?: "Dosya eklenemedi" }
        }
    }

    fun removePending(a: Att) {
        pending.value = pending.value - a
        a.file?.let { File(store.imgDir, it).delete() }
    }

    private fun displayName(uri: Uri): String {
        runCatching {
            app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0)
            }
        }
        return uri.lastPathSegment ?: "dosya"
    }

    private fun importText(uri: Uri): Att {
        val name = displayName(uri)
        val max = 300_000
        val bytes = app.contentResolver.openInputStream(uri)?.use { it.readNBytesCompat(max + 1) }
            ?: throw IOException("Dosya açılamadı")
        if (bytes.size > max) throw IOException("Dosya çok büyük (en fazla ~300 KB metin)")
        if (bytes.take(4000).any { it.toInt() == 0 }) throw IOException("Bu bir metin dosyası değil. Metin/kod dosyası ya da görsel ekleyin.")
        return Att(name, "text", text = String(bytes, Charsets.UTF_8))
    }

    private fun java.io.InputStream.readNBytesCompat(n: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (total < n) {
            val r = read(buf, 0, minOf(buf.size, n - total))
            if (r < 0) break
            out.write(buf, 0, r)
            total += r
        }
        return out.toByteArray()
    }

    private fun importImage(uri: Uri): Att {
        val name = displayName(uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("Görsel okunamadı")
        val scale = 1280f / maxOf(bmp.width, bmp.height)
        val out = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val fname = UUID.randomUUID().toString() + ".jpg"
        File(store.imgDir, fname).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        return Att(name, "image", file = fname)
    }

    // ------------------------------------------------------------------ Gönderme

    private fun newId() = UUID.randomUUID().toString()

    fun send(text: String) {
        if (generating.value) return
        val atts = pending.value
        if (text.isBlank() && atts.isEmpty()) return
        val s = settings.value
        if (s.apiKey.isBlank()) {
            notice.value = "Önce Ayarlar'dan Evren API anahtarını gir"
            screen.value = Screen.Settings
            return
        }
        val c = chat.value
        val user = Msg(newId(), "user", text.trim(), atts = atts)
        val title = if (c.msgs.isEmpty()) {
            (text.trim().ifBlank { atts.firstOrNull()?.name ?: "Yeni sohbet" }).lineSequence().first().take(40)
        } else c.title
        pending.value = emptyList()
        val persona = c.persona.ifBlank { s.persona }
        generate(c.copy(title = title, persona = persona, msgs = c.msgs + user))
    }

    fun stop() {
        job?.cancel()
    }

    fun regenerate() {
        if (generating.value) return
        val c = chat.value
        val base = if (c.msgs.lastOrNull()?.role == "assistant") c.copy(msgs = c.msgs.dropLast(1)) else c
        if (base.msgs.lastOrNull()?.role != "user") return
        generate(base)
    }

    fun editResend(id: String, text: String) {
        if (generating.value) return
        val c = chat.value
        val i = c.msgs.indexOfFirst { it.id == id }
        if (i < 0) return
        val u = c.msgs[i].copy(content = text.trim(), time = System.currentTimeMillis())
        generate(c.copy(msgs = c.msgs.take(i) + u))
    }

    fun deleteMsg(id: String) {
        if (generating.value) return
        val c = chat.value
        val n = c.copy(msgs = c.msgs.filter { it.id != id })
        chat.value = n
        if (n.msgs.isEmpty()) {
            viewModelScope.launch(Dispatchers.IO) { index.value = store.delete(n.id) }
        } else persist(n)
    }

    private fun systemPrompt(c: Conv, s: AppSettings): String? {
        val pid = c.persona.ifBlank { s.persona }
        val prompt = personas.value.firstOrNull { it.id == pid }?.prompt.orEmpty().trim()
        if (prompt.isEmpty()) return null
        val now = SimpleDateFormat("d MMMM yyyy, EEEE HH:mm", Locale("tr")).format(Date())
        return "$prompt\n\nŞu anki tarih ve saat: $now."
    }

    private fun supportsVision(model: String): Boolean {
        val m = model.lowercase()
        return m.contains("vl") || m.contains("vision") || m.contains("gpt-4") || m.contains("gemma-3") || m.contains("gemma-4")
    }

    private fun apiMessages(c: Conv, s: AppSettings): JsonArray {
        val vision = supportsVision(s.model)
        val hist = c.msgs
            .filter { it.role == "user" || (it.role == "assistant" && it.content.isNotBlank() && it.err.isEmpty()) }
            .takeLast(s.history.coerceAtLeast(2))
        val sys = systemPrompt(c, s)
        return buildJsonArray {
            if (sys != null) add(buildJsonObject { put("role", "system"); put("content", sys) })
            for (m in hist) {
                if (m.role == "assistant") {
                    add(buildJsonObject { put("role", "assistant"); put("content", m.content) })
                    continue
                }
                val files = m.atts.filter { it.kind == "text" }
                    .joinToString("") { "\n\n[Dosya: ${it.name}]\n```\n${it.text.orEmpty()}\n```" }
                val text = (m.content + files).ifBlank { "(ek)" }
                val imgs = if (vision) m.atts.filter { it.kind == "image" } else emptyList()
                if (imgs.isEmpty()) {
                    add(buildJsonObject { put("role", "user"); put("content", text) })
                } else {
                    add(buildJsonObject {
                        put("role", "user")
                        put("content", buildJsonArray {
                            add(buildJsonObject { put("type", "text"); put("text", text) })
                            for (a in imgs) {
                                val f = File(store.imgDir, a.file.orEmpty())
                                if (!f.exists()) continue
                                val b64 = Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
                                add(buildJsonObject {
                                    put("type", "image_url")
                                    put("image_url", buildJsonObject { put("url", "data:image/jpeg;base64,$b64") })
                                })
                            }
                        })
                    })
                }
            }
        }
    }

    private fun params(s: AppSettings, stream: Boolean = s.stream, max: Int = s.maxTokens, temp: Float = s.temperature) =
        ChatParams(s.baseUrl, s.apiKey, s.model, temp, max, stream)

    /** [base] son mesajı kullanıcı mesajı olan sohbet; yanıt üretilir ve sohbete eklenir. */
    private fun generate(base: Conv) {
        val s = settings.value
        val aId = newId()
        var cur = base.copy(updated = System.currentTimeMillis(), msgs = base.msgs + Msg(aId, "assistant", model = s.model))
        chat.value = cur
        persist(base)
        generating.value = true

        fun push(f: (Msg) -> Msg) {
            cur = cur.copy(msgs = cur.msgs.map { if (it.id == aId) f(it) else it })
            if (chat.value.id == cur.id) chat.value = cur
        }

        job = viewModelScope.launch {
            val content = StringBuilder()
            val reasoning = StringBuilder()
            var pt = 0
            var ct = 0
            var lastEmit = 0L
            fun emit(force: Boolean) {
                val now = SystemClock.uptimeMillis()
                if (!force && now - lastEmit < 60) return
                lastEmit = now
                val c = content.toString()
                val r = reasoning.toString()
                push { it.copy(content = c, reasoning = r) }
            }
            var err = ""
            try {
                withContext(Dispatchers.IO) {
                    val msgs = apiMessages(base, s)
                    Api.chat(params(s), msgs) { ev ->
                        when (ev) {
                            is Ev.Text -> { synchronized(content) { content.append(ev.s) }; emit(false) }
                            is Ev.Think -> { synchronized(content) { reasoning.append(ev.s) }; emit(false) }
                            is Ev.Usage -> { pt = ev.prompt; ct = ev.completion }
                        }
                    }
                }
            } catch (e: CancellationException) {
                // kullanıcı durdurdu
            } catch (e: Exception) {
                err = friendly(e)
                if (e is ApiException && e.code == "terms_not_accepted") termsNeeded.value = true
            }
            withContext(NonCancellable) {
                val c = content.toString()
                val r = reasoning.toString()
                if (c.isEmpty() && r.isEmpty() && err.isEmpty()) {
                    // hiçbir şey gelmeden durduruldu: boş yanıtı kaldır
                    cur = cur.copy(msgs = cur.msgs.filter { it.id != aId })
                    if (chat.value.id == cur.id) chat.value = cur
                } else {
                    push { it.copy(content = c, reasoning = r, promptTokens = pt, completionTokens = ct, err = err) }
                }
                cur = cur.copy(updated = System.currentTimeMillis())
                if (chat.value.id == cur.id) chat.value = cur
                generating.value = false
                val finalChat = cur
                withContext(Dispatchers.IO) { index.value = store.save(finalChat) }
                if (err.isEmpty() && c.isNotBlank() && s.autoTitle && finalChat.msgs.count { it.role == "user" } == 1) {
                    makeTitle(finalChat.id, finalChat.msgs.first { it.role == "user" }.content, c, s)
                }
            }
        }
    }

    private fun makeTitle(id: String, userText: String, answer: String, s: AppSettings) {
        if (userText.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val msgs = buildJsonArray {
                add(buildJsonObject {
                    put("role", "system")
                    put("content", "Aşağıdaki konuşma için en fazla 4 kelimelik kısa bir Türkçe başlık yaz. Yalnızca başlığı yaz; tırnak, nokta veya açıklama ekleme.")
                })
                add(buildJsonObject {
                    put("role", "user")
                    put("content", "Kullanıcı: ${userText.take(400)}\n\nAsistan: ${answer.take(400)}")
                })
            }
            val t = runCatching { Api.complete(params(s, stream = false, max = 40, temp = 0.3f), msgs) }.getOrNull()
                ?.lineSequence()?.firstOrNull { it.isNotBlank() }?.trim()?.trim('"', '\'', '*', '#', ' ', '.')
                ?.take(50)
            if (!t.isNullOrBlank()) renameChat(id, t)
        }
    }

    private fun friendly(e: Throwable): String = when (e) {
        is ApiException -> when {
            e.code == "terms_not_accepted" -> "Kullanım şartları henüz kabul edilmedi."
            e.status == 401 || e.status == 403 -> "API anahtarı geçersiz ya da yetkisiz (HTTP ${e.status}). Ayarlar'dan kontrol et. ${e.message.orEmpty()}".trim()
            e.status == 429 -> "İstek sınırı aşıldı (429). Biraz bekleyip tekrar dene. ${e.message.orEmpty()}".trim()
            e.status >= 500 -> "Sunucu hatası (HTTP ${e.status}). Tekrar dene. ${e.message.orEmpty()}".trim()
            e.status == 404 -> "Adres ya da model bulunamadı (404). Ayarlar'daki adresi ve model adını kontrol et. ${e.message.orEmpty()}".trim()
            else -> e.message.orEmpty().ifBlank { "İstek başarısız (HTTP ${e.status})" }
        }
        is java.net.SocketTimeoutException -> "Bağlantı zaman aşımına uğradı. İnternet yavaş olabilir; tekrar dene."
        is java.net.UnknownHostException -> "Sunucuya ulaşılamadı. İnternet bağlantını kontrol et."
        is IOException -> "Bağlantı hatası: ${e.message.orEmpty()}. İnternet yavaşsa tekrar dene."
        else -> e.message.orEmpty().ifBlank { "Bilinmeyen hata" }
    }

    override fun onCleared() {
        job?.cancel()
        super.onCleared()
    }
}
