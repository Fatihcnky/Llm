package com.example.evrenchat

import kotlinx.serialization.Serializable

/** Mesaja eklenen dosya: kind "text" (içeriği [text]'te) ya da "image" (uygulama içi dosya adı [file]). */
@Serializable
data class Att(val name: String, val kind: String, val text: String? = null, val file: String? = null)

@Serializable
data class Msg(
    val id: String,
    val role: String, // "user" | "assistant"
    val content: String = "",
    val reasoning: String = "",
    val atts: List<Att> = emptyList(),
    val time: Long = System.currentTimeMillis(),
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val err: String = "",
    val model: String = "",
)

@Serializable
data class Conv(
    val id: String,
    val title: String = "Yeni sohbet",
    val created: Long = System.currentTimeMillis(),
    val updated: Long = System.currentTimeMillis(),
    val pinned: Boolean = false,
    val persona: String = "",
    val msgs: List<Msg> = emptyList(),
)

@Serializable
data class ConvMeta(val id: String, val title: String, val updated: Long, val pinned: Boolean = false)

@Serializable
data class Persona(val id: String, val name: String, val prompt: String)

const val DEFAULT_BASE = "https://evren-llmapi.ssyz.org.tr/v1"
const val DEFAULT_MODEL = "deepseek-v4.1-flash"

data class AppSettings(
    val baseUrl: String = DEFAULT_BASE,
    val apiKey: String = "",
    val model: String = DEFAULT_MODEL,
    val temperature: Float = 0.7f,
    val maxTokens: Int = 0,
    val history: Int = 40,
    val stream: Boolean = true,
    val autoTitle: Boolean = true,
    val themeMode: Int = 0, // 0 koyu, 1 aydınlık, 2 sistem
    val accent: Int = 0,
    val fontScale: Float = 1f,
    val persona: String = "general",
)

val DefaultPersonas = listOf(
    Persona(
        "general", "Genel asistan",
        "Sen yardımcı, dürüst ve net bir yapay zekâ asistanısın. Kullanıcı hangi dilde yazarsa o dilde yanıt ver; belirsizse Türkçe yaz. " +
            "Gereksiz uzatma, ama gerektiğinde adım adım açıkla. Kod verirken biçimli kod blokları kullan ve neyi neden yaptığını kısaca söyle. " +
            "Emin olmadığın şeyi uydurma; bilmiyorsan bilmediğini söyle."
    ),
    Persona(
        "coder", "Yazılımcı",
        "Sen deneyimli bir yazılım mühendisisin. Çalışan, eksiksiz ve okunaklı kod yaz; hata ayıklarken önce olası nedeni söyle, sonra düzeltmeyi göster. " +
            "Kod bloklarında dil etiketini yaz. Türkçe açıkla, kod ve teknik terimleri olduğu gibi bırak."
    ),
    Persona(
        "translator", "Çevirmen (TR ⇄ EN)",
        "Sen profesyonel bir çevirmensin. Kullanıcı Türkçe yazarsa İngilizceye, başka dilde yazarsa Türkçeye çevir. Yalnızca çeviriyi ver; gerekirse sonda kısa bir not ekle. Anlamı ve tonu koru."
    ),
    Persona(
        "teacher", "Öğretmen",
        "Sen sabırlı bir öğretmensin. Konuyu basit anlatımla başla, örnek ver, sonra derinleştir. Anlayıp anlamadığını kontrol edecek kısa bir soru sorabilirsin. Türkçe yanıt ver."
    ),
    Persona("none", "Sistem istemi yok", ""),
)
