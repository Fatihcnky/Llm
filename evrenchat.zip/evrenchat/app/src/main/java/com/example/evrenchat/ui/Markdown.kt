package com.example.evrenchat.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------------------------------------------------------- Ayrıştırma

sealed interface Block {
    data class Para(val text: String) : Block
    data class Head(val level: Int, val text: String) : Block
    data class Code(val lang: String, val code: String) : Block
    data class Lst(val items: List<Item>) : Block
    data class Quote(val text: String) : Block
    data class Table(val rows: List<List<String>>) : Block
    data object Rule : Block
}

data class Item(val indent: Int, val marker: String, val text: String)

private val headRe = Regex("""^(#{1,6})\s+(.*)$""")
private val ruleRe = Regex("""^([-*_])(\s*\1){2,}$""")
private val listRe = Regex("""^(\s*)([-*+]|\d{1,3}[.)])\s+(.*)$""")
private val tableSep = Regex("""^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$""")

private fun splitRow(t: String): List<String> = t.trim().trim('|').split('|').map { it.trim() }

/** Akış sırasında kapanmamış kod bloğu da kod olarak gösterilir. */
fun parseBlocks(src: String): List<Block> {
    val out = ArrayList<Block>()
    val lines = src.replace("\r\n", "\n").split("\n")
    var i = 0
    val para = StringBuilder()
    fun flush() {
        if (para.isNotEmpty()) {
            out += Block.Para(para.toString().trimEnd())
            para.clear()
        }
    }
    while (i < lines.size) {
        val line = lines[i]
        val t = line.trim()
        if (t.startsWith("```") || t.startsWith("~~~")) {
            flush()
            val fence = t.take(3)
            val lang = t.drop(3).trim()
            val sb = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trim().startsWith(fence)) {
                sb.append(lines[i]).append('\n')
                i++
            }
            out += Block.Code(lang, sb.toString().trimEnd('\n'))
            i++
            continue
        }
        if (t.isEmpty()) { flush(); i++; continue }
        val h = headRe.matchEntire(t)
        if (h != null) {
            flush()
            out += Block.Head(h.groupValues[1].length, h.groupValues[2].trim())
            i++
            continue
        }
        if (ruleRe.matches(t)) { flush(); out += Block.Rule; i++; continue }
        if (t.startsWith("|") && i + 1 < lines.size && tableSep.matches(lines[i + 1].trim())) {
            flush()
            val rows = ArrayList<List<String>>()
            rows += splitRow(t)
            i += 2
            while (i < lines.size && lines[i].trim().startsWith("|")) {
                rows += splitRow(lines[i])
                i++
            }
            out += Block.Table(rows)
            continue
        }
        if (listRe.matches(line)) {
            flush()
            val items = ArrayList<Item>()
            while (i < lines.size) {
                val m = listRe.matchEntire(lines[i]) ?: break
                items += Item(m.groupValues[1].length / 2, m.groupValues[2], m.groupValues[3])
                i++
            }
            out += Block.Lst(items)
            continue
        }
        if (t.startsWith(">")) {
            flush()
            val sb = StringBuilder()
            while (i < lines.size && lines[i].trim().startsWith(">")) {
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(lines[i].trim().removePrefix(">").trim())
                i++
            }
            out += Block.Quote(sb.toString())
            continue
        }
        if (para.isNotEmpty()) para.append('\n')
        para.append(t)
        i++
    }
    flush()
    return out
}

// ---------------------------------------------------------------- Satır içi biçim

fun buildInline(src: String, link: Color, codeBg: Color): AnnotatedString =
    buildAnnotatedString { appendInline(src, link, codeBg) }

private fun AnnotatedString.Builder.appendInline(s: String, link: Color, codeBg: Color) {
    var i = 0
    val plain = StringBuilder()
    fun flushPlain() {
        if (plain.isNotEmpty()) {
            append(plain.toString())
            plain.clear()
        }
    }
    while (i < s.length) {
        val c = s[i]
        if (c == '\\' && i + 1 < s.length && s[i + 1] in "\\`*_{}[]()#+-.!|~>") {
            plain.append(s[i + 1]); i += 2; continue
        }
        if (c == '`') {
            val end = s.indexOf('`', i + 1)
            if (end > i) {
                flushPlain()
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg, fontSize = 0.92.em)) {
                    append(s.substring(i + 1, end))
                }
                i = end + 1
                continue
            }
        }
        if (s.startsWith("**", i) || s.startsWith("__", i)) {
            val tok = s.substring(i, i + 2)
            val end = s.indexOf(tok, i + 2)
            if (end > i + 2) {
                flushPlain()
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { appendInline(s.substring(i + 2, end), link, codeBg) }
                i = end + 2
                continue
            }
        }
        if (s.startsWith("~~", i)) {
            val end = s.indexOf("~~", i + 2)
            if (end > i + 2) {
                flushPlain()
                withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { appendInline(s.substring(i + 2, end), link, codeBg) }
                i = end + 2
                continue
            }
        }
        if (c == '*' || c == '_') {
            val prevOk = i == 0 || !s[i - 1].isLetterOrDigit()
            if (i + 1 < s.length && !s[i + 1].isWhitespace() && (c == '*' || prevOk)) {
                var end = s.indexOf(c, i + 1)
                while (end > 0 && c == '_' && end + 1 < s.length && s[end + 1].isLetterOrDigit()) end = s.indexOf(c, end + 1)
                if (end > i + 1 && !s[end - 1].isWhitespace()) {
                    flushPlain()
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { appendInline(s.substring(i + 1, end), link, codeBg) }
                    i = end + 1
                    continue
                }
            }
        }
        if (c == '[') {
            val close = s.indexOf("](", i)
            val end = if (close > 0) s.indexOf(')', close + 2) else -1
            if (close > i && end > close) {
                val label = s.substring(i + 1, close)
                val url = s.substring(close + 2, end).trim()
                if (url.startsWith("http")) {
                    flushPlain()
                    withLink(LinkAnnotation.Url(url, TextLinkStyles(SpanStyle(color = link, textDecoration = TextDecoration.Underline)))) {
                        append(label)
                    }
                    i = end + 1
                    continue
                }
            }
        }
        if (c == 'h' && (s.startsWith("http://", i) || s.startsWith("https://", i))) {
            var end = i
            while (end < s.length && !s[end].isWhitespace() && s[end] !in "<>\"") end++
            val url = s.substring(i, end).trimEnd('.', ',', ';', ':', '!', '?', ')')
            if (url.length > 8) {
                flushPlain()
                withLink(LinkAnnotation.Url(url, TextLinkStyles(SpanStyle(color = link, textDecoration = TextDecoration.Underline)))) {
                    append(url)
                }
                i += url.length
                continue
            }
        }
        plain.append(c)
        i++
    }
    flushPlain()
}

// ---------------------------------------------------------------- Görünüm

private val CodeBg = Color(0xFF14161B)
private val CodeFg = Color(0xFFE6E8EE)
private val CodeMuted = Color(0xFF9AA0AA)

@Composable
fun Markdown(text: String, modifier: Modifier = Modifier, scale: Float = 1f) {
    val blocks = remember(text) { parseBlocks(text) }
    val cs = MaterialTheme.colorScheme
    val link = cs.primary
    val codeBg = cs.onSurface.copy(alpha = 0.12f)
    val body = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp * scale, lineHeight = 24.sp * scale)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        blocks.forEach { b ->
            when (b) {
                is Block.Para -> {
                    val a = remember(b.text, link, codeBg) { buildInline(b.text, link, codeBg) }
                    Text(a, style = body)
                }
                is Block.Head -> {
                    val k = when (b.level) { 1 -> 1.5f; 2 -> 1.3f; 3 -> 1.15f; else -> 1.05f }
                    val a = remember(b.text, link, codeBg) { buildInline(b.text, link, codeBg) }
                    Text(
                        a,
                        style = body.copy(fontSize = 16.sp * scale * k, lineHeight = 24.sp * scale * k, fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
                is Block.Code -> CodeBlock(b.lang, b.code, scale)
                is Block.Lst -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    b.items.forEach { item ->
                        Row(Modifier.padding(start = (item.indent * 16).dp)) {
                            val marker = if (item.marker.length == 1) "•" else item.marker
                            Text(marker, style = body, modifier = Modifier.width(if (marker == "•") 18.dp else 28.dp))
                            val a = remember(item.text, link, codeBg) { buildInline(item.text, link, codeBg) }
                            Text(a, style = body, modifier = Modifier.weight(1f))
                        }
                    }
                }
                is Block.Quote -> Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(Modifier.width(3.dp).fillMaxHeight().background(cs.primary.copy(alpha = 0.6f)))
                    Spacer(Modifier.width(10.dp))
                    val a = remember(b.text, link, codeBg) { buildInline(b.text, link, codeBg) }
                    Text(a, style = body.copy(color = cs.onSurface.copy(alpha = 0.75f), fontStyle = FontStyle.Italic))
                }
                is Block.Table -> TableBlock(b.rows, body.fontSize, link, codeBg)
                Block.Rule -> HorizontalDivider()
            }
        }
    }
}

@Composable
private fun TableBlock(rows: List<List<String>>, size: androidx.compose.ui.unit.TextUnit, link: Color, codeBg: Color) {
    val cs = MaterialTheme.colorScheme
    val cols = rows.maxOfOrNull { it.size } ?: 0
    Column(
        Modifier
            .horizontalScroll(rememberScrollState())
            .clip(RoundedCornerShape(8.dp))
            .border(0.5.dp, cs.outline.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
    ) {
        rows.forEachIndexed { r, row ->
            Row(Modifier.background(if (r == 0) cs.surfaceVariant else Color.Transparent)) {
                for (c in 0 until cols) {
                    val cell = row.getOrElse(c) { "" }
                    val a = remember(cell, link, codeBg) { buildInline(cell, link, codeBg) }
                    Text(
                        a,
                        fontSize = size * 0.92f,
                        fontWeight = if (r == 0) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier
                            .width(130.dp)
                            .border(0.25.dp, cs.outline.copy(alpha = 0.3f))
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun CodeBlock(lang: String, code: String, scale: Float = 1f) {
    val clip = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CodeBg)) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF1E2128)).padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        ) {
            Text(lang.ifBlank { "kod" }, color = CodeMuted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(
                if (copied) "Kopyalandı ✓" else "Kopyala",
                color = CodeFg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable {
                        clip.setText(AnnotatedString(code))
                        copied = true
                    }
                    .padding(horizontal = 8.dp, vertical = 2.dp),
            )
        }
        Text(
            code,
            color = CodeFg,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp * scale,
            lineHeight = 19.sp * scale,
            softWrap = false,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(12.dp),
        )
    }
}

fun toastCopied(ctx: android.content.Context) {
    Toast.makeText(ctx, "Kopyalandı", Toast.LENGTH_SHORT).show()
}
