# Evren Sohbet

Evren AI LLM geçidi (varsayılan model `deepseek-v4.1-flash`) ile konuşan, OpenAI uyumlu her sunucuyla da çalışan Android sohbet uygulaması.

## Derleme (GitHub, bilgisayarsız)
1. Depoya `evrenchat.zip` dosyasını ve `.github/workflows/build.yml` dosyasını yükle.
2. Actions → "Evren Sohbet APK" → Run workflow.
3. Bitince "EvrenSohbet-apk" çıktısındaki `app-debug.apk` dosyasını indirip kur.
   Her derleme aynı imzayla çıkar; eskisini silmeden güncellenir (ilk kurulumda eski bir imzalı sürüm varsa bir kez silmen gerekir).

## İlk kullanım
1. Ayarlar → Bağlantı → API anahtarını (`evren_llm_…`) yapıştır.
2. "Bağlantıyı test et" → yeni anahtarlarda kullanım şartları istenirse "Kullanım şartlarını kabul et".
3. Model: `deepseek-v4.1-flash` (listeden başka model de seçebilirsin; görsel için `qwen3-vl-30b`).
4. Kaydet.

Adres: `https://evren-llmapi.ssyz.org.tr/v1` — Evren geçidi ücretsizdir; belgelerine göre günde 15M jeton, 5 dakikada 2.5M jeton ve 32 eşzamanlı istek sınırı vardır.

## Özellikler
- Canlı akan yanıt, durdur düğmesi, yeniden üret, mesajı düzenleyip yeniden gönder, mesaj silme
- Markdown: başlık, liste, tablo, alıntı, bağlantı, kod blokları (tek dokunuşla kopyala)
- Modelin "düşünce süreci" varsa açılır kutuda gösterilir
- Çoklu sohbet: geçmiş, arama, sabitleme, yeniden adlandırma, silme, otomatik başlık, dışa aktarma/paylaşma
- Roller (sistem istemleri): hazır 5 rol, kendi rolünü ekle/düzenle; sohbet başına değiştirilebilir
- Ekler: metin/kod dosyası ve görsel (görsel için görüntü destekli model gerekir)
- Sesle yazma (Türkçe), diğer uygulamalardan "Paylaş" ile metin gönderme
- Tema: koyu / aydınlık / sistem + 6 vurgu rengi, yazı boyutu
- Yavaş (uydu) bağlantılar için uzun zaman aşımları; hata mesajları Türkçe ve açıklayıcı
- Sohbetler ve anahtar yalnızca cihazda saklanır

## Sınırlar
Bu bir sohbet uygulamasıdır: model dosya çalıştıramaz, internete girmez, bilgisayarını yönetmez. Dosya/kod yapıştırıp ondan yazdırabilir, çıktıyı kopyalayabilirsin.
